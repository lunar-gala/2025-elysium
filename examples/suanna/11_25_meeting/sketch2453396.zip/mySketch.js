function setup() {
	createCanvas(windowWidth, windowHeight);
	noStroke();
	angleMode(DEGREES);
}

const trans = 3 * 1000;
const colors = [[146, 153, 166], [42, 66, 46], [28, 45, 128], [138, 85, 39]];
const acts = ['emergence', 'blossom', 'hubris', 'embrace'];

const act1pos = [90, 67.5, 45, 22.5];
const act2pos = [112.5, 90, 67.5, 45];
const act3pos = [135, 112.5, 90, 67.5];
const act4pos = [157.5, 135, 112.5, 90];

const positions = [act1pos, act2pos, act3pos, act4pos];

let oldMillis = 0;
let count = 0;

let stage = 0;
let oldStage = 0;

let archive = false;

let d = 1000;

var direction = 1;

function draw() {
	background(255);
	
	millisecond = millis() - oldMillis;
	
	drawBackground();
	
	textOpacity = 255;
	if (millisecond < trans) {
		textOpacity = map(millisecond, 0, trans, 0, 255);
	} 
	
	fill(255, 255, 255, textOpacity);
	textSize(50);
	textAlign(LEFT, CENTER);
	if (archive == false) {
		text(acts[stage], windowWidth/32, windowHeight/2);
	} else {
		text("archive", windowWidth/32, windowHeight/2);
	}
	textAlign(CENTER, CENTER);
	
	drawCircle();
	drawNavBar();
	
	if (millis() < 2* trans) {
		opacity = map(millis(), 2* trans, trans, 0, 255);
		length = map(millis(), 2 * trans, trans, 0, windowHeight/2);
		fill(0);
		fill(0);
		rect(0, 0, windowWidth, length);
		rect(0, windowHeight-length, windowWidth, length);		
		fill(255, 255, 255, opacity);
		text('Use Arrow Keys to Navigate', windowWidth/2, windowHeight/2);
	} 
}

function drawBackground() {
	if (archive == false && direction < 99) {
		if (millisecond < trans) {
			curColor = interpColor(map(millisecond, 0, trans/2, 0, 1), colors[oldStage], colors[stage]);
			opacity = map(millisecond, 0, trans/2, 0, 255);
			fill(curColor[0],curColor[1],curColor[2]);
		} else {
			fill(colors[stage][0],colors[stage][1],colors[stage][2]);
		}
	} else if (archive == true) {
		if (millisecond < trans) {
			curColor = interpColor(map(millisecond, 0, trans/2, 0, 1), colors[stage], [0, 0, 0]);
			opacity = map(millisecond, 0, trans/2, 0, 255);
			fill(curColor[0],curColor[1],curColor[2]);
		} else {
			fill(0);
		}
	} else {
		if (millisecond < trans) {
			curColor = interpColor(map(millisecond, 0, trans/2, 0, 1), [0, 0, 0], colors[stage]);
			opacity = map(millisecond, 0, trans/2, 0, 255);
			fill(curColor[0],curColor[1],curColor[2]);
		} else {
			fill(colors[stage][0],colors[stage][1],colors[stage][2]);
		}
		
	}

	
	rect(0, 0, windowWidth, windowHeight);
}

function drawCircle() {
	var x0;
	var y0;
	
	var x1;
	var y1;
	
	var x2;
	var y2;
	
	var x3;
	var y3;
	
	if (archive == false && direction < 99) {
		cX = windowWidth/2;
		cY = 4 * windowHeight/3;
		
		// TODO: implement radial-ness
		
		if (millisecond < trans) {
			interp = map(millisecond, 0, trans, 0, 22.5);
			x0 = cos(interp * direction + positions[oldStage][0]) * d/2 + windowWidth/2;
			y0 = -sin(interp * direction + positions[oldStage][0]) * d/2 + cY;

			x1 = cos(interp * direction + positions[oldStage][1]) * d/2 + windowWidth/2;
			y1 = - sin(interp * direction + positions[oldStage][1]) * d/2 + cY;

			x2 = cos(interp * direction + positions[oldStage][2]) * d/2 + windowWidth/2;
			y2 = - sin(interp * direction + positions[oldStage][2]) * d/2 + cY;

			x3 = cos(interp * direction + positions[oldStage][3]) * d/2 + windowWidth/2;
			y3 = - sin(interp * direction + positions[oldStage][3]) * d/2 + cY;
		} else {
			x0 = cos (positions[stage][0]) * d/2 + windowWidth/2;
			y0 = - sin (positions[stage][0]) * d/2 + cY;

			x1 = cos (positions[stage][1]) * d/2 + windowWidth/2;
			y1 = - sin (positions[stage][1]) * d/2 + cY;

			x2 = cos (positions[stage][2]) * d/2 + windowWidth/2;
			y2 = - sin (positions[stage][2]) * d/2 + cY;

			x3 = cos (positions[stage][3]) * d/2 + windowWidth/2;
			y3 = - sin (positions[stage][3]) * d/2 + cY;
		} 
		
	} else if (archive == false && direction == 99999) {
		if (millisecond < trans) {
			cY= map(millisecond, 0, trans, - windowHeight/2, 4 * windowHeight/3);
		} else {
			cY = 4 * windowHeight/3;
		}
		x0 = cos (positions[stage][0]) * d/2 + windowWidth/2;
		y0 = - sin (positions[stage][0]) * d/2 + cY;

		x1 = cos (positions[stage][1]) * d/2 + windowWidth/2;
		y1 = - sin (positions[stage][1]) * d/2 + cY;

		x2 = cos (positions[stage][2]) * d/2 + windowWidth/2;
		y2 = - sin (positions[stage][2]) * d/2 + cY;

		x3 = cos (positions[stage][3]) * d/2 + windowWidth/2;
		y3 = - sin (positions[stage][3]) * d/2 + cY;
		
		cX = windowWidth/2;
		
	} else {
		if (millisecond < trans) {
			cY= map(millisecond, 0, trans, 4 * windowHeight/3, - windowHeight/2);
		} else {
			cY = - windowHeight/2;
		}
		x0 = cos (positions[stage][0]) * d/2 + windowWidth/2;
		y0 = - sin (positions[stage][0]) * d/2 + cY;

		x1 = cos (positions[stage][1]) * d/2 + windowWidth/2;
		y1 = - sin (positions[stage][1]) * d/2 + cY;

		x2 = cos (positions[stage][2]) * d/2 + windowWidth/2;
		y2 = - sin (positions[stage][2]) * d/2 + cY;

		x3 = cos (positions[stage][3]) * d/2 + windowWidth/2;
		y3 = - sin (positions[stage][3]) * d/2 + cY;
		
		
		cX = windowWidth/2;
	}
	
	noFill();
	stroke(255)
	circle(cX, cY, d);
	noStroke();
	fill(255);
	circle(x0, y0, 30);
	circle(x1, y1, 30);
	circle(x2, y2, 30);
	circle(x3, y3, 30);
}

function drawNavBar() {
	if (archive == false && direction < 99) {
		cY = windowHeight/32;
	} else if (archive == true) {
		if (millisecond < trans) cY = map(millisecond, 0, trans, windowHeight/32, - windowHeight); 
		else {cY = -100};
	} else if (archive == false){
		if (millisecond < trans) cY = map(millisecond, 0, trans, - windowHeight, windowHeight/32);
		else cY = cY = windowHeight/32;
	}
	noFill();
	stroke(255);
	textSize(12);
	rect(windowWidth * 1/2 - windowWidth/8 - windowWidth/32, cY, windowWidth * 1/16, windowHeight/32);
	noStroke();
	fill(255);
	text('ABOUT', windowWidth * (1/2 - 1/8), cY + windowHeight/64);
	noFill();
	stroke(255);
	rect(windowWidth * 1/2 - windowWidth/32 , cY, windowWidth * 1/16, windowHeight/32);
	noStroke();
	fill(255);
	text('PEOPLE', windowWidth * (1/2), cY + windowHeight/64);
	noFill();
	stroke(255);
	rect(windowWidth * (1/2 + 1/8 - 1/32), cY, windowWidth * 1/16, windowHeight/32);
	noStroke();
	fill(255);
	text('TICKETS', windowWidth * (1/2 + 1/8), cY + windowHeight/64);
	noFill();
	noStroke();
}


function keyPressed() {
	if (archive == false) {
		if( key == 'ArrowLeft') {
			oldStage = stage;
			stage = (stage - 1)%4;
			oldMillis = millis()*1.0;
			direction = -1;
			if (stage < 0) stage += 4;
		} else if (key == 'ArrowRight') {
			oldStage = stage;
			stage = (stage + 1)%4;
			oldMillis = millis()*1.0;
			direction = 1;
		} 
	}
	if (key == 'ArrowUp') {
		if (archive == false) {
			archive = true;
			oldMillis = millis()*1.0;
			direction = 99999;
		}
	} else if (key == 'ArrowDown') {
		if (archive == true) {
			archive = false;
			oldMillis = millis()*1.0;
			direction = 99999;
		}
	}
}

function interpColor(n, color1, color2) {
	newColor = [];
	if (n > 1) return color2;
	for (var i = 0; i < 3; i ++) {
		newColor[i] = color1[i] + (color2[i] - color1[i])*n;
	}
	return newColor;
}

