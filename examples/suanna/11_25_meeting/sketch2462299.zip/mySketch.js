var w;
var h;
var start;

function setup() {
	w = windowWidth;
	h = windowHeight;
	createCanvas(w, h);
	background(100);
	start = true;
}

function draw() {
	var dia = 500;
	background(100);
	translate(w/2, h/2);
	rotate(PI/6);
	fill(255);
	circle(0, 0, dia);
	drawCurve(0, - dia/2, 0, dia/2, dia);
	noFill();
	
	rotate(-PI/25);
	circle(0, 0, dia/2);
	drawCurve(0, - dia/4, 0, dia/4, dia/2);
	
	rotate(-PI/25);
	circle(0, 0, dia/4);
	drawCurve(0, - dia/8, 0, dia/8, dia/4);
	
	rotate(-PI/25);
	circle(0, 0, dia/8);
	drawCurve(0, - dia/16, 0, dia/16, dia/8);
	
	rotate(-PI/25);
	circle(0, 0, dia/16);
	drawCurve(0, - dia/32, 0, dia/32, dia/16);
}

function drawCurve(x0, y0, x1, y1, dia) {
	if (cos(millis()/2000*PI) < -0.99) start = false;
	if (cos(millis()/2000*PI) > 0.99) start = true;
	var xHandle = 2*dia/3.01 * cos(millis()/2000*PI);
	var yHandle = 0;
	if (start == true) bezier(x0, y0, x0 + xHandle, y0 + yHandle, 
					 x1 + xHandle, y1 + yHandle, x1, y1);
}