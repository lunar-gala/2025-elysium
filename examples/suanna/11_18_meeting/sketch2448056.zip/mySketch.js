var w;
var dx = 50;
var h = 1;
var opacity = 0;

function setup() {
	createCanvas(windowWidth, windowHeight);
	background(255);
	w = windowWidth;
	
}

var cols = 60;
var rows = 2;

function draw() {
	background(255);
	w = sin(millis()/1000) * 50 + windowWidth;
	h = map(abs(mouseY-windowHeight/2), 0, windowHeight/2, 1, 1.03);
	drawArcs(2);
	drawArcs(4);
	drawArcs(6);
	drawArcs(8);
	drawArcs(10);
	drawArcs(12);
	drawArcs(14);
	drawArcs(16);
	if (mouseIsPressed) drawGuidelines();
}

function drawGuidelines() {
	stroke(200);
	for (i = 0; i < cols; i ++) {
		line(i * w/cols + dx, 0, i * w/cols + dx, windowHeight);
	} for (i = 0; i < rows; i ++) {
		line(0, i * windowHeight/rows, w, i * windowHeight/rows);
	}
}

function drawArcs(level) {
	for (i = 0; i < cols/level; i ++) {
		var dir = i % 2;
		drawArc(level*(i) * w/cols + level/2*w/(cols) + dx, level*(i + 1)* w/cols + level/2*w/(cols) + dx, dir);
	}
}

function drawArc(start, end, direction) {
  noFill();
  stroke(0, 0, 0, opacity);
  strokeWeight(0.5);
	var ang;
	if( millis() < 5000) {
		ang = map(millis(), 0, 5000, 0, PI);
		opacity = map(millis(), 0, 5000, 0, 255);
	} else {
		ang = PI;
	}
	if (direction == 1) {
		arc(start, windowHeight/2, end - start, h * (end - start), ang - PI, ang, OPEN);
	} else {
		arc(start, windowHeight/2, end - start, h * (start - end), ang, 0, OPEN);
	}
}